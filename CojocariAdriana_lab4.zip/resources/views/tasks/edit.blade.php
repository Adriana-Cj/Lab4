@extends('layouts.app')

@section('title', 'Editează Sarcină')

@push('styles')
<style>
    /* Task Form Styles */
    .container {
        max-width: 800px;
        margin: 0 auto;
        padding: 2rem 1rem;
    }

    /* Card styling */
    form.needs-validation {
        background: #ffffff;
        border-radius: 12px;
        padding: 2rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        margin-top: 1.5rem;
    }

    /* Page title */
    h1 {
        color: #1a202c;
        font-size: 1.875rem;
        font-weight: 600;
        margin-bottom: 1.5rem;
        padding-bottom: 1rem;
        border-bottom: 2px solid #e2e8f0;
    }

    /* Form groups */
    .mb-3 {
        margin-bottom: 1.5rem !important;
    }

    /* Labels */
    .form-label {
        font-weight: 500;
        color: #4a5568;
        margin-bottom: 0.5rem;
        display: block;
    }

    /* Required field indicator */
    .text-danger {
        color: #e53e3e !important;
    }

    /* Form controls */
    .form-control {
        width: 100%;
        padding: 0.75rem 1rem;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        transition: all 0.2s;
        background-color: #fff;
    }

    .form-control:focus {
        border-color: #4299e1;
        box-shadow: 0 0 0 3px rgba(66, 153, 225, 0.15);
        outline: none;
    }

    .form-control.is-invalid {
        border-color: #fc8181;
    }

    /* Help text */
    .form-text {
        color: #718096;
        font-size: 0.875rem;
        margin-top: 0.25rem;
    }

    /* Error messages */
    .alert-danger {
        background-color: #fff5f5;
        border: 1px solid #feb2b2;
        border-radius: 8px;
        color: #c53030;
        padding: 1rem;
        margin-bottom: 1.5rem;
    }

    .alert-danger ul {
        margin: 0;
        padding-left: 1.25rem;
    }

    .invalid-feedback {
        color: #e53e3e;
        font-size: 0.875rem;
        margin-top: 0.25rem;
    }

    /* Tags section */
    .row.g-2 {
        display: flex;
        flex-wrap: wrap;
        gap: 0.75rem;
        margin: 0;
    }

    .col-auto {
        background-color: #f7fafc;
        border: 1px solid #e2e8f0;
        border-radius: 6px;
        padding: 0.5rem 1rem;
    }

    /* Checkboxes */
    .form-check {
        padding-left: 1.75rem;
        margin-bottom: 0;
    }

    .form-check-input {
        width: 1.125rem;
        height: 1.125rem;
        margin-top: 0.25rem;
        margin-left: -1.75rem;
        border: 1.5px solid #cbd5e0;
        border-radius: 0.25rem;
    }

    .form-check-input:checked {
        background-color: #4299e1;
        border-color: #4299e1;
    }

    .form-check-label {
        color: #4a5568;
        font-size: 0.95rem;
    }

    /* Buttons */
    .d-flex.gap-2 {
        margin-top: 2rem;
    }

    .btn {
        padding: 0.625rem 1.25rem;
        border-radius: 8px;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        transition: all 0.2s;
    }

    .btn-primary {
        background-color: #4299e1;
        border-color: #4299e1;
        color: white;
    }

    .btn-primary:hover {
        background-color: #3182ce;
        border-color: #3182ce;
    }

    .btn-secondary {
        background-color: #edf2f7;
        border-color: #edf2f7;
        color: #4a5568;
    }

    .btn-secondary:hover {
        background-color: #e2e8f0;
        border-color: #e2e8f0;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .container {
            padding: 1rem;
        }
        
        form.needs-validation {
            padding: 1.5rem;
        }
        
        h1 {
            font-size: 1.5rem;
        }
    }
</style>
@endpush

@section('content')
<div class="container">
    <h1>Editează Sarcină</h1>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('tasks.update', $task->id) }}" method="POST" class="needs-validation" novalidate>
        @csrf
        @method('PUT')
        
        <div class="mb-3">
            <label for="title" class="form-label">Titlu <span class="text-danger">*</span></label>
            <input type="text" 
                   class="form-control @error('title') is-invalid @enderror" 
                   id="title" 
                   name="title" 
                   value="{{ old('title', $task->title) }}"
                   minlength="3"
                   required>
            @error('title')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Descriere</label>
            <textarea class="form-control @error('description') is-invalid @enderror" 
                      id="description" 
                      name="description" 
                      rows="3"
                      maxlength="500">{{ old('description', $task->description) }}</textarea>
            @error('description')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
            <div class="form-text">Maxim 500 caractere</div>
        </div>

        <div class="mb-3">
            <label for="due_date" class="form-label">Data limită <span class="text-danger">*</span></label>
            <input type="date" 
                   class="form-control @error('due_date') is-invalid @enderror" 
                   id="due_date" 
                   name="due_date"
                   value="{{ old('due_date', $task->due_date->format('Y-m-d')) }}"
                   min="{{ date('Y-m-d') }}"
                   required>
            @error('due_date')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="category_id" class="form-label">Categoria <span class="text-danger">*</span></label>
            <select class="form-control @error('category_id') is-invalid @enderror" 
                    id="category_id" 
                    name="category_id"
                    required>
                <option value="">Selectează categoria</option>
                @foreach($categories as $category)
                    <option value="{{ $category->id }}" 
                            {{ old('category_id', $task->category_id) == $category->id ? 'selected' : '' }}>
                        {{ $category->name }}
                    </option>
                @endforeach
            </select>
            @error('category_id')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label class="form-label d-block">Etichete</label>
            <div class="row g-2">
                @foreach($tags as $tag)
                    <div class="col-auto">
                        <div class="form-check">
                            <input class="form-check-input" 
                                   type="checkbox" 
                                   name="tags[]" 
                                   value="{{ $tag->id }}" 
                                   id="tag{{ $tag->id }}"
                                   {{ in_array($tag->id, old('tags', $task->tags->pluck('id')->toArray())) ? 'checked' : '' }}>
                            <label class="form-check-label" for="tag{{ $tag->id }}">
                                {{ $tag->name }}
                            </label>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>

        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save me-1"></i> Salvează Modificările
            </button>
            <a href="{{ route('tasks.show', $task->id) }}" class="btn btn-secondary">
                <i class="fas fa-times me-1"></i> Anulează
            </a>
        </div>
    </form>
</div>

@push('scripts')
<script>
(function () {
    'use strict'
    var forms = document.querySelectorAll('.needs-validation')
    Array.prototype.slice.call(forms)
        .forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }
                form.classList.add('was-validated')
            }, false)
        })
})()
</script>
@endpush
@endsection