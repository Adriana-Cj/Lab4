@extends('layouts.app')

@section('title', 'Creează Sarcină Nouă')

@push('styles')
<style>
    .task-form-container {
        max-width: 800px;
        margin: 2rem auto;
        padding: 2rem;
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 15px rgba(0, 0, 0, 0.05);
    }

    .page-title {
        color: #2c3e50;
        font-size: 2rem;
        font-weight: 600;
        margin-bottom: 1.5rem;
        padding-bottom: 1rem;
        border-bottom: 2px solid #eef2f7;
    }

    .form-label {
        font-weight: 500;
        color: #4a5568;
        margin-bottom: 0.5rem;
    }

    .form-control {
        border: 1.5px solid #e2e8f0;
        border-radius: 8px;
        padding: 0.625rem 1rem;
        transition: all 0.2s ease-in-out;
    }

    .form-control:focus {
        border-color: #4299e1;
        box-shadow: 0 0 0 3px rgba(66, 153, 225, 0.15);
    }

    .form-control.is-invalid {
        border-color: #e53e3e;
        box-shadow: none;
    }

    .btn {
        padding: 0.625rem 1.25rem;
        font-weight: 500;
        border-radius: 8px;
        transition: all 0.2s ease-in-out;
    }

    .btn-primary {
        background-color: #4299e1;
        border-color: #4299e1;
    }

    .btn-primary:hover {
        background-color: #3182ce;
        border-color: #3182ce;
    }

    .btn-secondary {
        background-color: #edf2f7;
        border-color: #edf2f7;
        color: #4a5568;
    }

    .btn-secondary:hover {
        background-color: #e2e8f0;
        border-color: #e2e8f0;
    }

    .form-check-input {
        width: 1.125rem;
        height: 1.125rem;
        margin-top: 0.25rem;
    }

    .form-check-label {
        color: #4a5568;
        padding-left: 0.25rem;
    }

    .tags-container {
        display: flex;
        flex-wrap: wrap;
        gap: 0.75rem;
        padding: 0.5rem 0;
    }

    .tag-item {
        background-color: #f7fafc;
        border: 1px solid #e2e8f0;
        border-radius: 6px;
        padding: 0.375rem 0.75rem;
    }

    .alert-danger {
        background-color: #fff5f5;
        border-color: #feb2b2;
        color: #c53030;
        border-radius: 8px;
        padding: 1rem;
        margin-bottom: 1.5rem;
    }

    .form-text {
        color: #718096;
        font-size: 0.875rem;
        margin-top: 0.375rem;
    }

    /* Animații pentru validare */
    .was-validated .form-control:valid {
        border-color: #48bb78;
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3e%3cpath fill='%2348bb78' d='M2.3 6.73L.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3e%3c/svg%3e");
        background-repeat: no-repeat;
        background-position: right calc(0.375em + 0.1875rem) center;
        background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
    }
</style>
@endpush

@section('content')
<div class="container">
    <div class="task-form-container">
        <h1 class="page-title">Creează Sarcină Nouă</h1>

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('tasks.store') }}" method="POST" class="needs-validation" novalidate>
            @csrf
            
            <div class="mb-3">
                <label for="title" class="form-label">Titlu <span class="text-danger">*</span></label>
                <input type="text" 
                       class="form-control @error('title') is-invalid @enderror" 
                       id="title" 
                       name="title" 
                       value="{{ old('title') }}"
                       minlength="3"
                       required>
                @error('title')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Descriere</label>
                <textarea class="form-control @error('description') is-invalid @enderror" 
                          id="description" 
                          name="description" 
                          rows="3"
                          maxlength="500">{{ old('description') }}</textarea>
                @error('description')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
                <div class="form-text">Maxim 500 caractere</div>
            </div>

            <div class="mb-3">
                <label for="due_date" class="form-label">Data limită <span class="text-danger">*</span></label>
                <input type="date" 
                       class="form-control @error('due_date') is-invalid @enderror" 
                       id="due_date" 
                       name="due_date"
                       value="{{ old('due_date') }}"
                       min="{{ date('Y-m-d') }}"
                       required>
                @error('due_date')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label for="category_id" class="form-label">Categoria <span class="text-danger">*</span></label>
                <select class="form-control @error('category_id') is-invalid @enderror" 
                        id="category_id" 
                        name="category_id"
                        required>
                    <option value="">Selectează categoria</option>
                    @foreach($categories as $category)
                        <option value="{{ $category->id }}" 
                                {{ old('category_id') == $category->id ? 'selected' : '' }}>
                            {{ $category->name }}
                        </option>
                    @endforeach
                </select>
                @error('category_id')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label class="form-label d-block">Etichete</label>
                <div class="tags-container">
                    @foreach($tags as $tag)
                        <div class="tag-item">
                            <div class="form-check">
                                <input class="form-check-input" 
                                       type="checkbox" 
                                       name="tags[]" 
                                       value="{{ $tag->id }}" 
                                       id="tag{{ $tag->id }}"
                                       {{ in_array($tag->id, old('tags', [])) ? 'checked' : '' }}>
                                <label class="form-check-label" for="tag{{ $tag->id }}">
                                    {{ $tag->name }}
                                </label>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Creează Sarcina
                </button>
                <a href="{{ route('tasks.index') }}" class="btn btn-secondary">
                    <i class="fas fa-times me-1"></i> Anulează
                </a>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<script>
(function () {
    'use strict'
    var forms = document.querySelectorAll('.needs-validation')
    Array.prototype.slice.call(forms)
        .forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }
                form.classList.add('was-validated')
            }, false)
        })
})()
</script>
@endpush
@endsection