@extends('layouts.app')

@section('title', 'Lista de sarcini')

@section('content')
    <h1>Lista de sarcini</h1>
    <div class="task-grid">
        @foreach ($tasks as $task)
            <x-task-card :task="$task" />
        @endforeach
    </div>
@endsection