<div class="task-card">
    <h2>{{ $task->title }}</h2>
    
    @if($task->status)
        <span class="task-status {{ $task->completed ? 'status-completed' : 'status-active' }}">
            {{ $task->completed ? 'Completat' : 'Activ' }}
        </span>
    @endif
    
    <div class="task-info">
        <p>{{ $task->description }}</p>
        
        @if($task->category)
            <p>
                <strong>Categoria:</strong>
                <span class="badge">{{ $task->category->name }}</span>
            </p>
        @endif
        
        <p>
            <strong>Prioritate:</strong>
            <span class="badge priority-{{ strtolower($task->priority) }}">
                {{ $task->priority }}
            </span>
        </p>
        
        @if($task->tags->count() > 0)
            <div class="tags-container">
                @foreach($task->tags as $tag)
                    <span class="tag">{{ $tag->name }}</span>
                @endforeach
            </div>
        @endif
    </div>
    
    <div class="task-actions">
        <a href="{{ route('tasks.show', $task->id) }}" class="btn btn-details">Vezi detalii</a>
        <a href="{{ route('tasks.edit', $task->id) }}" class="btn btn-edit">Editează</a>
        <form action="{{ route('tasks.destroy', $task->id) }}" method="POST" class="d-inline">
            @csrf
            @method('DELETE')
            <button type="submit" class="btn btn-delete" onclick="return confirm('Ești sigur?')">Șterge</button>
        </form>
    </div>
</div>
