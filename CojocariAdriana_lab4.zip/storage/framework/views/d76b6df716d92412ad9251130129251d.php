

<?php $__env->startSection('title', 'Editează Sarcină'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    /* Task Form Styles */
    .container {
        max-width: 800px;
        margin: 0 auto;
        padding: 2rem 1rem;
    }

    /* Card styling */
    form.needs-validation {
        background: #ffffff;
        border-radius: 12px;
        padding: 2rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        margin-top: 1.5rem;
    }

    /* Page title */
    h1 {
        color: #1a202c;
        font-size: 1.875rem;
        font-weight: 600;
        margin-bottom: 1.5rem;
        padding-bottom: 1rem;
        border-bottom: 2px solid #e2e8f0;
    }

    /* Form groups */
    .mb-3 {
        margin-bottom: 1.5rem !important;
    }

    /* Labels */
    .form-label {
        font-weight: 500;
        color: #4a5568;
        margin-bottom: 0.5rem;
        display: block;
    }

    /* Required field indicator */
    .text-danger {
        color: #e53e3e !important;
    }

    /* Form controls */
    .form-control {
        width: 100%;
        padding: 0.75rem 1rem;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        transition: all 0.2s;
        background-color: #fff;
    }

    .form-control:focus {
        border-color: #4299e1;
        box-shadow: 0 0 0 3px rgba(66, 153, 225, 0.15);
        outline: none;
    }

    .form-control.is-invalid {
        border-color: #fc8181;
    }

    /* Help text */
    .form-text {
        color: #718096;
        font-size: 0.875rem;
        margin-top: 0.25rem;
    }

    /* Error messages */
    .alert-danger {
        background-color: #fff5f5;
        border: 1px solid #feb2b2;
        border-radius: 8px;
        color: #c53030;
        padding: 1rem;
        margin-bottom: 1.5rem;
    }

    .alert-danger ul {
        margin: 0;
        padding-left: 1.25rem;
    }

    .invalid-feedback {
        color: #e53e3e;
        font-size: 0.875rem;
        margin-top: 0.25rem;
    }

    /* Tags section */
    .row.g-2 {
        display: flex;
        flex-wrap: wrap;
        gap: 0.75rem;
        margin: 0;
    }

    .col-auto {
        background-color: #f7fafc;
        border: 1px solid #e2e8f0;
        border-radius: 6px;
        padding: 0.5rem 1rem;
    }

    /* Checkboxes */
    .form-check {
        padding-left: 1.75rem;
        margin-bottom: 0;
    }

    .form-check-input {
        width: 1.125rem;
        height: 1.125rem;
        margin-top: 0.25rem;
        margin-left: -1.75rem;
        border: 1.5px solid #cbd5e0;
        border-radius: 0.25rem;
    }

    .form-check-input:checked {
        background-color: #4299e1;
        border-color: #4299e1;
    }

    .form-check-label {
        color: #4a5568;
        font-size: 0.95rem;
    }

    /* Buttons */
    .d-flex.gap-2 {
        margin-top: 2rem;
    }

    .btn {
        padding: 0.625rem 1.25rem;
        border-radius: 8px;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        transition: all 0.2s;
    }

    .btn-primary {
        background-color: #4299e1;
        border-color: #4299e1;
        color: white;
    }

    .btn-primary:hover {
        background-color: #3182ce;
        border-color: #3182ce;
    }

    .btn-secondary {
        background-color: #edf2f7;
        border-color: #edf2f7;
        color: #4a5568;
    }

    .btn-secondary:hover {
        background-color: #e2e8f0;
        border-color: #e2e8f0;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .container {
            padding: 1rem;
        }
        
        form.needs-validation {
            padding: 1.5rem;
        }
        
        h1 {
            font-size: 1.5rem;
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Editează Sarcină</h1>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('tasks.update', $task->id)); ?>" method="POST" class="needs-validation" novalidate>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="mb-3">
            <label for="title" class="form-label">Titlu <span class="text-danger">*</span></label>
            <input type="text" 
                   class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                   id="title" 
                   name="title" 
                   value="<?php echo e(old('title', $task->title)); ?>"
                   minlength="3"
                   required>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Descriere</label>
            <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                      id="description" 
                      name="description" 
                      rows="3"
                      maxlength="500"><?php echo e(old('description', $task->description)); ?></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="form-text">Maxim 500 caractere</div>
        </div>

        <div class="mb-3">
            <label for="due_date" class="form-label">Data limită <span class="text-danger">*</span></label>
            <input type="date" 
                   class="form-control <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                   id="due_date" 
                   name="due_date"
                   value="<?php echo e(old('due_date', $task->due_date->format('Y-m-d'))); ?>"
                   min="<?php echo e(date('Y-m-d')); ?>"
                   required>
            <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label for="category_id" class="form-label">Categoria <span class="text-danger">*</span></label>
            <select class="form-control <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                    id="category_id" 
                    name="category_id"
                    required>
                <option value="">Selectează categoria</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" 
                            <?php echo e(old('category_id', $task->category_id) == $category->id ? 'selected' : ''); ?>>
                        <?php echo e($category->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label class="form-label d-block">Etichete</label>
            <div class="row g-2">
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-auto">
                        <div class="form-check">
                            <input class="form-check-input" 
                                   type="checkbox" 
                                   name="tags[]" 
                                   value="<?php echo e($tag->id); ?>" 
                                   id="tag<?php echo e($tag->id); ?>"
                                   <?php echo e(in_array($tag->id, old('tags', $task->tags->pluck('id')->toArray())) ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="tag<?php echo e($tag->id); ?>">
                                <?php echo e($tag->name); ?>

                            </label>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save me-1"></i> Salvează Modificările
            </button>
            <a href="<?php echo e(route('tasks.show', $task->id)); ?>" class="btn btn-secondary">
                <i class="fas fa-times me-1"></i> Anulează
            </a>
        </div>
    </form>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    'use strict'
    var forms = document.querySelectorAll('.needs-validation')
    Array.prototype.slice.call(forms)
        .forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }
                form.classList.add('was-validated')
            }, false)
        })
})()
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\todo-app\resources\views/tasks/edit.blade.php ENDPATH**/ ?>